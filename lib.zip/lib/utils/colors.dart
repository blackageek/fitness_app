  import 'package:flutter/material.dart';

  const mainColor =Color(0xff0186A4);
  // const mainColor =Color(0xff0176ed);
  const mainGrey =Color(0xffc8c8c8);
  const main2 = Color(0xFFf9764b);
